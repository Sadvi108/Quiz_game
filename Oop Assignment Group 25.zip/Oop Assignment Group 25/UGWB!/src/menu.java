import java.util.*;

public class menu {
    static Dictionary<Integer, String> sectionList = new Hashtable<Integer,String>();

    static ArrayList<String> titleList0 = new ArrayList<String>();
    static ArrayList<String> titleList1 = new ArrayList<String>();
    static ArrayList<String> titleList2 = new ArrayList<String>();
    static ArrayList<String> titleList3 = new ArrayList<String>();
    static ArrayList<String> titleList4 = new ArrayList<String>();
    static ArrayList<String> titleList5 = new ArrayList<String>();

    static ArrayList<String> contentList0 = new ArrayList<String>();
    static ArrayList<String> contentList1 = new ArrayList<String>();
    static ArrayList<String> contentList2 = new ArrayList<String>();
    static ArrayList<String> contentList3 = new ArrayList<String>();
    static ArrayList<String> contentList4 = new ArrayList<String>();
    static ArrayList<String> contentList5 = new ArrayList<String>();

    static ArrayList<String> sourceList0 = new ArrayList<String>();
    static ArrayList<String> sourceList1 = new ArrayList<String>();
    static ArrayList<String> sourceList2 = new ArrayList<String>();
    static ArrayList<String> sourceList3 = new ArrayList<String>();
    static ArrayList<String> sourceList4= new ArrayList<String>();
    static ArrayList<String> sourceList5 = new ArrayList<String>();
    
    static ArrayList<String> feedbackList0 = new ArrayList<String>();
    static ArrayList<String> feedbackList1 = new ArrayList<String>();
    static ArrayList<String> feedbackList2 = new ArrayList<String>();
    static ArrayList<String> feedbackList3 = new ArrayList<String>();
    static ArrayList<String> feedbackList4 = new ArrayList<String>();
    static ArrayList<String> feedbackList5 = new ArrayList<String>();

    
    public static void onStartUp() {
        sectionList.put(0, "What is Global Warming?");
        sectionList.put(1, "First few Cases of Global Warming");
        sectionList.put(2, "What are the Effects of Global Warming?");
        sectionList.put(3, "Where are the Effects of Global Warming most evident?");
        sectionList.put(4, "Why does Global Warming occur?");
        sectionList.put(5, "What we can do to reduce the Effects of Global Warming.");

        titleList0.add("Global Warming");
        contentList0.add("Global warming is the long-term warming of the planet’s overall temperature. Though this warming\ntrend has been going on for a long time, its pace has significantly increased in the last hundred\nyears due to the burning of fossil fuels. As the human population has increased, so has the volume\nof fossil fuels burned. Fossil fuels include coal, oil, and natural gas, and burning them causes\nwhat is known as the “greenhouse effect” in Earth’s atmosphere.\n\nThe greenhouse effect is when the sun’s rays penetrate the atmosphere, but when that heat is\nreflected off the surface cannot escape back into space. Gases produced by the burning of fossil\nfuels prevent the heat from leaving the atmosphere. These greenhouse gasses are carbon dioxide,\nchlorofluorocarbons, water vapor, methane, and nitrous oxide. The excess heat in the atmosphere\nhas caused the average global temperature to rise overtime, otherwise known as global warming.");
        sourceList0.add("https://education.nationalgeographic.org/resource/global-warming/");

        titleList1.add("How Do We Know Climate Change Is Real?");
        contentList1.add("In 1896, a seminal paper by Swedish scientist Svante Arrhenius first predicted that changes in\natmospheric carbon dioxide levels could substantially alter the surface temperature through the \ngreenhouse effect.\n\nIn 1938, Guy Callendar connected carbon dioxide increases in Earth’s atmosphere to global warming. ");
        sourceList1.add("https://climate.nasa.gov/evidence/#:~:text=In%201896%2C%20a%20seminal%20paper,Earth%27s%20atmosphere%20to%20global%20warming.");
        
        titleList2.add("Global temperature rise could see billions live in places where human life doesn’t flourish, study says");
        contentList2.add("Factoring in both the expected global warming and population growth, the study found that by 2030\n around two billion people will be outside the climate niche, facing average temperatures of 29\ndegrees Celsius (84 degrees Fahrenheit) or higher, with around 3.7 billion living outside the\nniche by 2090.");
        sourceList2.add("https://edition.cnn.com/2023/05/23/asia/global-warming-billions-dangerous-climate-heat-report-intl-hnk/index.html");

        titleList3.add("The Great Barrier Reef, Australia");
        contentList3.add("Spanning more than 1,400 miles, the Great Barrier Reef off the\nnortheast coast of Australia is the largest coral reef system in the world. Replete with marine\nlife, it draws millions of snorkelers and scuba divers each year. But rising ocean temperatures\nhave caused coral bleaching - a condition in which the coral turns white and becomes prone to mass\ndie-offs - destroying a vital habitat for marine life. As of 2020, an aerial survey by the Great\nBarrier Reef Foundation revealed the third mass bleaching in five years, with 60 percent of the\nreef's living corals dying as a result. ");
        sourceList3.add("https://www.cntraveler.com/gallery/10-places-to-visit-before-theyre-lost-to-climate-change");

        titleList4.add("What Are the Causes of Climate Change?");
        contentList4.add("Global warming occurs when carbon dioxide (CO2) and other air pollutants collect in the atmosphere\nand absorb sunlight and solar radiation that have bounced off the earth’s surface. Normally this\nradiation would escape into space, but these pollutants, which can last for years to centuries in\nthe atmosphere, trap the heat and cause the planet to get hotter. These heat-trapping pollutants\nspecifically carbon dioxide, methane, nitrous oxide, water vapor, and synthetic fluorinated gases\nare known as greenhouse gases, and their impact is called the greenhouse effect. ");
        sourceList4.add("https://www.nrdc.org/stories/what-are-causes-climate-change#natural");

        titleList5.add("Speak Up");
        contentList5.add("By talking to your friends and family, voicing your concerns out to the public,you send a message\nthat you care about the warming world. Encourage Congress to enact new laws that limit carbon\nemissions and require polluters to pay for the emissions they produce.  ");
        sourceList5.add("https://www.nrdc.org/stories/how-you-can-stop-global-warming");
    }

    public static void addArticle(String newTitle, String newContent, String newSource) {
        int choice;
        Scanner choiceScanner = new Scanner(System.in);
        choice = choiceScanner.nextInt();
        switch (choice) {
            case 0: {
                titleList0.add(newTitle);
                contentList0.add(newContent);
                sourceList0.add(newSource);
                break;
            }
            case 1: {
                titleList1.add(newTitle);
                contentList1.add(newContent);
                sourceList1.add(newSource);
                break;
            }
            case 2: {
                titleList2.add(newTitle);
                contentList2.add(newContent);
                sourceList2.add(newSource);
                break;
            }
            case 3: {
                titleList3.add(newTitle);
                contentList3.add(newContent);
                sourceList3.add(newSource);
                break;
            }
            case 4: {
                titleList4.add(newTitle);
                contentList4.add(newContent);
                sourceList4.add(newSource);
                break;
            }
            case 5: {
                titleList5.add(newTitle);
                contentList5.add(newContent);
                sourceList5.add(newSource);
                break;
            }
            default: {
                System.out.println(colours.redBoldBright + "Unable to add article!" + colours.reset);
            }
        }
        System.out.println(colours.greenBoldBright + "Article successfully added!" + colours.reset);
        
    }


    public static void sectionView(int a) {
        int l = 0;
        int viewChoice;
        Scanner sectionViewScanner = new Scanner(System.in);
        try {
            switch (a) {
                case 0: {
                    if (titleList0.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to view!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList0.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList0.get(i) + colours.reset);
                        }
                        viewChoice = sectionViewScanner.nextInt();
                        System.out.println(colours.whiteUnderlined + colours.whiteBoldBright + titleList0.get(viewChoice) + colours.reset);
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println(contentList0.get(viewChoice));
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println("[Source: " + sourceList0.get(viewChoice) + "]");
                        break;
                    }
                }
                case 1: {
                    if (titleList1.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to view!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList1.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList1.get(i) + colours.reset);
                        }
                        viewChoice = sectionViewScanner.nextInt();
                        System.out.println(colours.whiteUnderlined + colours.whiteBoldBright + titleList1.get(viewChoice) + colours.reset);
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println(contentList1.get(viewChoice));
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println("[Source: " + sourceList1.get(viewChoice) + "]");
                        break;
                    }
                }
                case 2: {
                    if (titleList2.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to view!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList2.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList2.get(i) + colours.reset);
                        }
                        viewChoice = sectionViewScanner.nextInt();
                        System.out.println(colours.whiteUnderlined + colours.whiteBoldBright + titleList2.get(viewChoice) + colours.reset);
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println(contentList2.get(viewChoice));
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println("[Source: "+ sourceList2.get(viewChoice) + "]");
                        break;
                    }
                }
                case 3: {
                    if (titleList3.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to view!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList3.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList3.get(i) + colours.reset);
                        }
                        viewChoice = sectionViewScanner.nextInt();
                        System.out.println(colours.whiteUnderlined + colours.whiteBoldBright + titleList3.get(viewChoice) + colours.reset);
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println(contentList3.get(viewChoice));
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println("[Source: " + sourceList3.get(viewChoice) + "]");
                        break;
                    }
                }
                case 4: {
                    if (titleList4.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to view!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList4.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList4.get(i) + colours.reset);
                        }
                        viewChoice = sectionViewScanner.nextInt();
                        System.out.println(colours.whiteUnderlined + colours.whiteBoldBright + titleList4.get(viewChoice) + colours.reset);
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println(contentList4.get(viewChoice));
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println("[Source: " + sourceList4.get(viewChoice) + "]");
                        break;
                    }
                }
                case 5: {
                    if (titleList5.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to view!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList5.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList5.get(i) + colours.reset);
                        }
                        viewChoice = sectionViewScanner.nextInt();
                        System.out.println(colours.whiteUnderlined + colours.whiteBoldBright + titleList5.get(viewChoice) + colours.reset);
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println(contentList5.get(viewChoice));
                        do {
                            lines.emptyline();
                            l++;
                        } while (l < 1);
                        System.out.println("[Source: " + sourceList5.get(viewChoice) + "]");
                        break;
                    }  
                }
                default: {
                    System.out.println(colours.redBoldBright + "You have selected nothing!" + colours.reset);
                    break;
                }
            }
        } 
        catch (Exception e) {
            System.out.println(colours.redBoldBright + "Please enter a valid input!" + colours.reset);
        }    
    }

    public static void removeArticle(int a) {
        int l = 0;
        int removeChoice;
        Scanner removeArticlScanner = new Scanner(System.in);
        try {
            switch (a) {
                case 0: {
                    if (titleList0.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to remove!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.redBoldBright + "Which article would you like to remove?" + colours.reset);
                        for (int i = 0; i < titleList0.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList0.get(i) + colours.reset);
                        }
                        removeChoice = removeArticlScanner.nextInt();
                        titleList0.remove(removeChoice);
                        contentList0.remove(removeChoice);
                        sourceList0.remove(removeChoice);
                        System.out.println(colours.greenBoldBright + "Article successfully removed!" + colours.reset);
                        break;
                    }
                    
                }
                case 1: {
                    if (titleList1.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to remove!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.redBoldBright + "Which article would you like to remove?" + colours.reset);
                        for (int i = 0; i < titleList1.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList1.get(i) + colours.reset);
                        }
                        removeChoice = removeArticlScanner.nextInt();
                        titleList1.remove(removeChoice);
                        contentList1.remove(removeChoice);
                        sourceList1.remove(removeChoice);
                        System.out.println(colours.greenBoldBright + "Article successfully removed!" + colours.reset);
                        break;
                    }
                    
                }
                case 2: {
                    if (titleList2.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to remove!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.redBoldBright + "Which article would you like to remove?" + colours.reset);
                        for (int i = 0; i < titleList2.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList2.get(i) + colours.reset);
                        }
                        removeChoice = removeArticlScanner.nextInt();
                        titleList2.remove(removeChoice);
                        contentList2.remove(removeChoice);
                        sourceList2.remove(removeChoice);
                        System.out.println(colours.greenBoldBright + "Article successfully removed!" + colours.reset);
                        break;
                    }
                }
                case 3: {
                    if (titleList3.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to remove!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.redBoldBright + "Which article would you like to remove?" + colours.reset);
                        for (int i = 0; i < titleList3.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList3.get(i) + colours.reset);
                        }
                        removeChoice = removeArticlScanner.nextInt();
                        titleList3.remove(removeChoice);
                        contentList3.remove(removeChoice);
                        sourceList3.remove(removeChoice);
                        System.out.println(colours.greenBoldBright + "Article successfully removed!" + colours.reset);
                        break;
                    }
                    
                }
                case 4: {
                    if (titleList4.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to remove!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.redBoldBright + "Which article would you like to remove?" + colours.reset);
                        for (int i = 0; i < titleList4.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList4.get(i) + colours.reset);
                        }
                        removeChoice = removeArticlScanner.nextInt();
                        titleList4.remove(removeChoice);
                        contentList4.remove(removeChoice);
                        sourceList4.remove(removeChoice);
                        System.out.println(colours.greenBoldBright + "Article successfully removed!" + colours.reset);
                        break;
                    }
                    
                }
                case 5: {
                    if (titleList5.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to remove!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.redBoldBright + "Which article would you like to remove?" + colours.reset);
                        for (int i = 0; i < titleList5.size(); i++) {
                            System.out.println("(" + i + ")" + colours.whiteUnderlined + titleList5.get(i) + colours.reset);
                        }
                        removeChoice = removeArticlScanner.nextInt();
                        titleList5.remove(removeChoice);
                        contentList5.remove(removeChoice);
                        sourceList5.remove(removeChoice);
                        System.out.println(colours.greenBoldBright + "Article successfully removed!" + colours.reset);
                        break;
                    }
                }
                default: {
                    System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                    break;
                }
        }
     } catch (Exception e) {
            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
        }
    }

    public static void editArticle(int a) {
        int l = 0;
        int editChoice;
        String editTitle, editContent, editSource;
        Scanner editScanner = new Scanner(System.in);
        Scanner editScanner_1 = new Scanner(System.in);
        Scanner editScanner_2 = new Scanner(System.in);
        Scanner editScanner_3 = new Scanner(System.in);
        try {
            switch(a) {
                case 0: {
                    if (titleList0.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to edit!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to modify?" + colours.reset);
                        for (int i = 0; i < titleList0.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList0.get(i) + colours.reset);
                        }
                        editChoice = editScanner.nextInt();
                        System.out.println("You have chosen to modify (" + editChoice + ")." );
                        try {
                            System.out.println(colours.yellowBoldBright + "What is the new title?" + colours.reset);
                            editTitle = editScanner_1.nextLine();
                            titleList0.remove(editChoice);
                            titleList0.add(editChoice,editTitle);

                            System.out.println(colours.yellowBoldBright + "What is the new content?" + colours.reset);
                            editContent = editScanner_2.nextLine();
                            contentList0.remove(editChoice);
                            contentList0.add(editChoice,editContent);

                            System.out.println(colours.yellowBoldBright + "What is the new source?" + colours.reset);
                            editSource = editScanner_3.nextLine();
                            sourceList0.remove(editChoice);
                            sourceList0.add(editChoice, editSource);
                            break;
                        } catch (Exception e) {
                            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                            break;
                        }
                    }
                    
                    
                }
                case 1: {
                    if (titleList1.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to edit!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to modify?" + colours.reset);
                        for (int i = 0; i < titleList1.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList1.get(i) + colours.reset);
                        }
                        editChoice = editScanner.nextInt();
                        System.out.println("You have chosen to modify (" + editChoice + ")." );
                        try {
                            editChoice = editScanner.nextInt();
                            System.out.println("You have chosen to modify (" + editChoice + ")." );
                            System.out.println(colours.yellowBoldBright + "What is the new title?" + colours.reset);
                            editTitle = editScanner_1.nextLine();
                            titleList1.remove(editChoice);
                            titleList1.add(editChoice,editTitle);

                            System.out.println(colours.yellowBoldBright + "What is the new content?" + colours.reset);
                            editContent = editScanner_2.nextLine();
                            contentList1.remove(editChoice);
                            contentList1.add(editChoice,editContent);

                            System.out.println(colours.yellowBoldBright + "What is the new source?" + colours.reset);
                            editSource = editScanner_3.nextLine();
                            sourceList1.remove(editChoice);
                            sourceList1.add(editChoice, editSource);
                            break;

                        } catch (Exception e) {
                            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                            break;
                        }
                    }
                    
                }
                case 2: {
                    if (titleList2.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to edit!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to modify?" + colours.reset);
                        for (int i = 0; i < titleList2.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList2.get(i) + colours.reset);
                        }
                        editChoice = editScanner.nextInt();
                        System.out.println("You have chosen to modify (" + editChoice + ")." ); 
                        try {
                            editChoice = editScanner.nextInt();
                            System.out.println("You have chosen to modify (" + editChoice + ")." );
                            System.out.println(colours.yellowBoldBright + "What is the new title?" + colours.reset);
                            editTitle = editScanner_1.nextLine();
                            titleList2.remove(editChoice);
                            titleList2.add(editChoice,editTitle);

                            System.out.println(colours.yellowBoldBright + "What is the new content?" + colours.reset);
                            editContent = editScanner_2.nextLine();
                            contentList2.remove(editChoice);
                            contentList2.add(editChoice,editContent);

                            System.out.println(colours.yellowBoldBright + "What is the new source?" + colours.reset);
                            editSource = editScanner_3.nextLine();
                            sourceList2.remove(editChoice);
                            sourceList2.add(editChoice, editSource);
                            break;
                        } catch (Exception e) {
                            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                            break;
                        }
                    }
                }
                case 3: {
                    if (titleList3.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to edit!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to modify?" + colours.reset);
                        for (int i = 0; i < titleList3.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList3.get(i) + colours.reset);
                        } 
                        editChoice = editScanner.nextInt();
                        System.out.println("You have chosen to modify (" + editChoice + ")." );
                        try {
                            System.out.println(colours.yellowBoldBright + "What is the new title?" + colours.reset);
                            editTitle = editScanner_1.nextLine();
                            titleList3.remove(editChoice);
                            titleList3.add(editChoice,editTitle);

                            System.out.println(colours.yellowBoldBright + "What is the new content?" + colours.reset);
                            editContent = editScanner_2.nextLine();
                            contentList3.remove(editChoice);
                            contentList3.add(editChoice,editContent);

                            System.out.println(colours.yellowBoldBright + "What is the new source?" + colours.reset);
                            editSource = editScanner_3.nextLine();
                            sourceList3.remove(editChoice);
                            sourceList3.add(editChoice, editSource);
                            break;
                        } catch (Exception e) {
                            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                            break;
                        }
                    }
                }
                case 4: {
                    if (titleList4.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to edit!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to modify?" + colours.reset);
                        for (int i = 0; i < titleList4.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList4.get(i) + colours.reset);
                        } 
                        editChoice = editScanner.nextInt();
                        System.out.println("You have chosen to modify (" + editChoice + ")." );
                        try {
                            System.out.println(colours.yellowBoldBright + "What is the new title?" + colours.reset);
                            editTitle = editScanner_1.nextLine();
                            titleList4.remove(editChoice);
                            titleList4.add(editChoice,editTitle);

                            System.out.println(colours.yellowBoldBright + "What is the new content?" + colours.reset);
                            editContent = editScanner_2.nextLine();
                            contentList4.remove(editChoice);
                            contentList4.add(editChoice,editContent);

                            System.out.println(colours.yellowBoldBright + "What is the new source?" + colours.reset);
                            editSource = editScanner_3.nextLine();
                            sourceList4.remove(editChoice);
                            sourceList4.add(editChoice, editSource);
                            break;
                        } catch (Exception e) {
                            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                            break;
                        }
                    }
                }
                case 5: {
                    if (titleList5.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to edit!" + colours.reset);
                        break;
                    }       
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to modify?" + colours.reset);
                        for (int i = 0; i < titleList5.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList5.get(i) + colours.reset);
                        } 
                        editChoice = editScanner.nextInt();
                        System.out.println("You have chosen to modify (" + editChoice + ")." );
                        try {
                            System.out.println(colours.yellowBoldBright + "What is the new title?" + colours.reset);
                            editTitle = editScanner_1.nextLine();
                            titleList5.remove(editChoice);
                            titleList5.add(editChoice,editTitle);

                            System.out.println(colours.yellowBoldBright + "What is the new content?" + colours.reset);
                            editContent = editScanner_2.nextLine();
                            contentList5.remove(editChoice);
                            contentList5.add(editChoice,editContent);

                            System.out.println(colours.yellowBoldBright + "What is the new source?" + colours.reset);
                            editSource = editScanner_3.nextLine();
                            sourceList5.remove(editChoice);
                            sourceList5.add(editChoice, editSource);
                            break;
                        } catch (Exception e) {
                            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                            break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
        }
    }

    public static void viewFeedback(int a) {
        int l = 0;
        int feedbackChoice;
        Scanner feedbackScanner = new Scanner(System.in);
        try {
            switch (a) {
                case 0: {
                    if (feedbackList0.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There is no feedback to view!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article's feedbacks would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList0.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList0.get(i) + colours.reset);
                        }
                        feedbackChoice = feedbackScanner.nextInt();
                        for (int b = 0; b < feedbackList0.size(); b++) {
                            System.out.println("(" + b + ") - " + feedbackList0.get(b) + colours.reset);
                            lines.emptyline();
                        }
                    }
                    break;

                }
                case 1: {
                    if (feedbackList1.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There is no feedback to view!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article's feedbacks would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList1.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList1.get(i) + colours.reset);
                        }
                        feedbackChoice = feedbackScanner.nextInt();
                        for (int b = 0; b < feedbackList1.size(); b++) {
                            System.out.println("(" + b + ") - " + feedbackList1.get(b) + colours.reset);
                            lines.emptyline();
                        }
                    }
                    break;
                }
                case 2: {
                    if (feedbackList2.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There is no feedback to view!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article's feedbacks would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList2.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList2.get(i) + colours.reset);
                        }
                        feedbackChoice = feedbackScanner.nextInt();
                        for (int b = 0; b < feedbackList2.size(); b++) {
                            System.out.println("(" + b + ") - " + feedbackList2.get(b) + colours.reset);
                            lines.emptyline();
                        }
                    }
                    break;
                }
                case 3: {
                    if (feedbackList3.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There is no feedback to view!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article's feedbacks would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList3.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList3.get(i) + colours.reset);
                        }
                        feedbackChoice = feedbackScanner.nextInt();
                        for (int b = 0; b < feedbackList3.size(); b++) {
                            System.out.println("(" + b + ") - " + feedbackList3.get(b) + colours.reset);
                            lines.emptyline();
                        }
                    }
                    break;
                }
                case 4: {
                    if (feedbackList4.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There is no feedback to view!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article's feedbacks would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList4.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList4.get(i) + colours.reset);
                        }
                        feedbackChoice = feedbackScanner.nextInt();
                        for (int b = 0; b < feedbackList4.size(); b++) {
                            System.out.println("(" + b + ") - " + feedbackList4.get(b) + colours.reset);
                            lines.emptyline();
                        }
                    }
                    break;
                }
                case 5: {
                    if (feedbackList5.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There is no feedback to view!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article's feedbacks would you like to view?" + colours.reset);
                        for (int i = 0; i < titleList5.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList5.get(i) + colours.reset);
                        }
                        feedbackChoice = feedbackScanner.nextInt();
                        for (int b = 0; b < feedbackList5.size(); b++) {
                            System.out.println("(" + b + ") - " + feedbackList5.get(b) + colours.reset);
                            lines.emptyline();
                        }
                    }
                    break;
                }
                default: {
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
        }
    }

    public static void giveFeedback(int a) {
        int articleChoice;
        Scanner articleScanner = new Scanner(System.in);
        Scanner givenFeedback = new Scanner(System.in);
        try {
            switch (a) {
                case 0: {
                    System.out.println(colours.yellowBoldBright + "Which article would you like to give feedback on?" + colours.reset);
                    if (titleList0.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to give feedback on!" + colours.reset);
                    }
                    else {
                        for (int i = 0; i < titleList0.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList0.get(i) + colours.reset);
                        }
                        articleChoice = articleScanner.nextInt();
                        System.out.println(colours.yellowBoldBright + "What is your feedback?" + colours.reset);
                        String feedback = givenFeedback.nextLine();
                        feedbackList0.add(articleChoice, feedback);                       
                    }
                    break;
                }
                case 1: {
                    System.out.println(colours.yellowBoldBright + "Which article would you like to give feedback on?" + colours.reset);
                    if (titleList1.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to give feedback on!" + colours.reset);
                    }
                    else {
                        for (int i = 0; i < titleList1.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList1.get(i) + colours.reset);
                        }
                        articleChoice = articleScanner.nextInt();
                        System.out.println(colours.yellowBoldBright + "What is your feedback?" + colours.reset);
                        String feedback = givenFeedback.nextLine();
                        feedbackList1.add(articleChoice, feedback);                       
                    }
                    break;
                }
                case 2: {
                    if (titleList2.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to give feedback on!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to give feedback on?" + colours.reset);
                        for (int i = 0; i < titleList2.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList2.get(i) + colours.reset);
                        }
                        articleChoice = articleScanner.nextInt();
                        System.out.println(colours.yellowBoldBright + "What is your feedback?" + colours.reset);
                        String feedback = givenFeedback.nextLine();
                        feedbackList2.add(articleChoice, feedback);
                    }
                    break;
                }
                case 3: {
                    if (titleList3.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to give feedback on!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to give feedback on?" + colours.reset);
                        for (int i = 0; i < titleList3.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList3.get(i) + colours.reset);
                        }
                        articleChoice = articleScanner.nextInt();
                        System.out.println(colours.yellowBoldBright + "What is your feedback?" + colours.reset);
                        String feedback = givenFeedback.nextLine();
                        feedbackList3.add(articleChoice, feedback);
                    }
                    break;
                }
                case 4: {
                    if (titleList4.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to give feedback on!" + colours.reset);
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to give feedback on?" + colours.reset);
                        for (int i = 0; i < titleList4.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList4.get(i) + colours.reset);
                        }
                        articleChoice = articleScanner.nextInt();
                        System.out.println(colours.yellowBoldBright + "What is your feedback?" + colours.reset);
                        String feedback = givenFeedback.nextLine();
                        feedbackList4.add(articleChoice, feedback);
                    }
                    break;
                }
                case 5: {
                    if (titleList5.isEmpty()) {
                        System.out.println(colours.redBoldBright + "There are no articles to give feedback on!" + colours.reset);
                        break;
                    }
                    else {
                        System.out.println(colours.yellowBoldBright + "Which article would you like to give feedback on?" + colours.reset);
                        for (int i = 0; i < titleList5.size(); i++) {
                            System.out.println("(" + i + ") - " + colours.whiteUnderlined + titleList5.get(i) + colours.reset);
                        }
                        articleChoice = articleScanner.nextInt();
                        System.out.println(colours.yellowBoldBright + "What is your feedback?" + colours.reset);
                        String feedback = givenFeedback.nextLine();
                        feedbackList5.add(articleChoice, feedback);
                        break;
                    }
                    
                }
            }
        } catch (Exception e) {
            System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
        }
    }

    // Guest Page
    public static void guest(String user) {
        int l = 0;
        Scanner console = new Scanner(System.in);
        System.out.println(colours.yellowBoldBright + "Welcome " + user + "...\nPlease selct an option: " + colours.reset);

        while (true) {
            lines.emptyline();
            System.out.println("(0) - Read Article\n(1) - Give Feedback to Article\n(2) - Log Out");
            String choice = console.nextLine();
            if (choice.equals("0")) {
                System.out.println("Which section do you want to view?");
                System.out.println(colours.yellowBoldBright + "Section List" + colours.reset);
                for (int i = 0; i < sectionList.size(); i++) {
                    System.out.println("(" + i + ") - " + sectionList.get(i));
                }
                try {
                    int sectionViewOption;
                    Scanner option1_1 = new Scanner(System.in);
                    sectionViewOption = option1_1.nextInt();
                    sectionView(sectionViewOption);
                } catch (Exception e) {
                    System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                }
            }
            else if (choice.equals("1")) {
                System.out.println("Which section's article do you want to give feedback on?");
                System.out.println(colours.yellowBoldBright + "Section List" + colours.reset);
                for (int i = 0; i < sectionList.size(); i++) {
                    System.out.println("(" + i + ") - " + sectionList.get(i));
                }
                try {
                    int giveFeedbackOption;
                    Scanner option1_1 = new Scanner(System.in);
                    giveFeedbackOption = option1_1.nextInt();
                    giveFeedback(giveFeedbackOption);
                }
                catch (Exception e) {
                    System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                }
            }
            else if (choice.equals("2")) {
                System.out.println(colours.greenBoldBright + "Logging out..." + colours.reset);
                break;
            }
            else {
                System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
            }
        }
    }

    //Admin Page
    public static void admin() {
        int l = 0;
        Scanner console = new Scanner(System.in);
        String newTitle, newContent, newSource;

        System.out.println(colours.yellowBoldBright + "Welcome Admin...\nPlease select an option: " + colours.reset);
        while (true) {
            lines.emptyline();
            System.out.println("(0) - Add Article\n(1) - View Article\n(2) - Remove Article\n(3) - Edit Article\n(4) - View Article Feedback\n(5) - Log Out");
            String choice = console.nextLine();
            if (choice.equals("0")) {
                int sectionOption;
                Scanner option0_1 = new Scanner(System.in);
                Scanner option0_2 = new Scanner(System.in);
                Scanner option0_3 = new Scanner(System.in);
                
                lines.emptyline();
                System.out.println(colours.yellowBoldBright + "Please input the title..." + colours.reset);
                newTitle = option0_1.nextLine();
                System.out.println(colours.yellowBoldBright + "Please input the content..." + colours.reset);
                newContent = option0_2.nextLine();
                System.out.println(colours.yellowBoldBright + "Please input a source..." + colours.reset);
                newSource = option0_3.nextLine();

                do {
                    lines.emptyline();
                    l++;
                } while (l < 2);
                System.out.println(colours.yellowBoldBright + "Which section would you like this article to be put in?" + colours.reset);
                for (int i = 0; i < sectionList.size(); i++) {
                    System.out.println("(" + i + ") - " + sectionList.get(i));
                }
                addArticle(newTitle, newContent, newSource );
            }

            else if (choice.equals("1")) { // View Article
                System.out.println("Which section do you want to view?");
                System.out.println(colours.yellowBoldBright + "Section List" + colours.reset);
                for (int i = 0; i < sectionList.size(); i++) {
                    System.out.println("(" + i + ") - " + sectionList.get(i));
                }
                try {
                    int sectionViewOption;
                    Scanner option1_1 = new Scanner(System.in);
                    sectionViewOption = option1_1.nextInt();
                    sectionView(sectionViewOption);
                } catch (Exception e) {
                    System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                }
                
            }

            else if (choice.equals("2")) { // Remove article
                do {
                    lines.emptyline();
                    l++;
                } while (l < 2);
                
                System.out.println(colours.yellowBoldBright + "Which section do you want to modify?" + colours.reset);
                for (int i = 0; i < sectionList.size(); i++) {
                    System.out.println("(" + i + ") - " + sectionList.get(i));
                }
                try {
                    int deleteOption;
                    Scanner option2_1 = new Scanner(System.in);
                    deleteOption = option2_1.nextInt();
                    removeArticle(deleteOption);
                } catch (Exception e) {
                    System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                }
            }

            else if (choice.equals("3")) {
                do {
                    lines.emptyline();
                    l++;
                } while (l < 2);

                System.out.println(colours.yellowBoldBright + "Which section do you want to modify?" + colours.reset);
                for (int i = 0; i < sectionList.size(); i++) {
                    System.out.println("(" + i + ") - " + sectionList.get(i));
                }
                try {
                    int editOption;
                    Scanner option3_1 = new Scanner(System.in);
                    editOption = option3_1.nextInt();
                    editArticle(editOption);
                } catch (Exception e) {
                    System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                }
            }
            
            else if (choice.equals("4")) {
                System.out.println(colours.yellowBoldBright + "Which section's article's feedback would you like to view?" + colours.reset);
                for (int i = 0; i < sectionList.size(); i++) {
                    System.out.println("(" + i + ") - " + sectionList.get(i));
                }
                try {
                    int feedbackViewOption;
                    Scanner option4_1 = new Scanner(System.in);
                    feedbackViewOption = option4_1.nextInt();
                    viewFeedback(feedbackViewOption);
                } catch (Exception e) {
                    System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                }
            }
            else if (choice.equals("5")) {
                System.out.println(colours.greenBoldBright + "Logging out..." + colours.reset);
                break;
            }
            else {
                System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
            }
        }
    }
}