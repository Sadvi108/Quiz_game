import java.util.*; // Scanner, ArrayList, Dictionary Class
public class loginPage extends menu {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        Dictionary acc = new Hashtable<String, String>();

        acc.put("admin", "admin123");
        acc.put("guest", "guest123");

        ArrayList<String> accountList = new ArrayList<String>(); //An array of accounts
        for (Enumeration e = acc.keys(); e.hasMoreElements();) {
            accountList.add(String.valueOf(e.nextElement())); //Adds admin and guest accounts upon program startup
        }

        boolean loop = true;

        while (loop) {
            lines.startUpLine();
            System.out.println(colours.yellowUnderlined + colours.yellowBold + "| WELCOME TO UGWB |" + colours.reset);
            System.out.println("Login or Create an Account?\n(0) - Create new Account\n(1) - Login to Existing Account\n(2) - Quit Program");
            String choice = console.nextLine();

                if (choice.equals("0")) {
                    System.out.println(colours.yellowBoldBright + "Enter new username: " + colours.reset);
                    String username = console.nextLine();

                    if (accountList.contains(username)) {
                        System.out.println(colours.redBoldBright + "Username already exists!" + colours.reset);
                    }

                    else {
                        System.out.println(colours.yellowBoldBright + "Enter new password: " + colours.reset);
                        String password = console.nextLine();

                        System.out.println(colours.yellowBoldBright + "Reenter Password: " + colours.reset); 
                        String newpass = console.nextLine();

                        if (password.equals(newpass)) {
                            acc.put(username,password);

                            for (Enumeration e = acc.keys(); e.hasMoreElements();) {
                                accountList.add(String.valueOf(e.nextElement()));
                            }
                            lines.longLine();
                            System.out.println(colours.greenBoldBright + colours.greenUnderlined + "| Successfully created a new account! |\n" + colours.reset);
                        }

                        else {
                            System.out.println(colours.redBoldBright + "Failed to create new account!\n" + colours.reset);
                        }
                    }
                }

                else if (choice.equals("1")) {
                    System.out.println(colours.yellowBoldBright + "Enter username: " + colours.reset);
                    String user = console.nextLine();

                    if (user.equals("admin")) {
                        System.out.println(colours.yellowBoldBright + "Please enter your password: " + colours.reset);
                        String pass = console.nextLine();

                        if (pass.equals(acc.get("admin"))) {
                            System.out.println(colours.greenBoldBright + "\nLogin successful!\n" + colours.reset);
                            menu.onStartUp();
                            menu.admin();// Goes to admin page
                        }
                        else {
                            System.out.println(colours.redBoldBright + "Invalid password!" + colours.reset); //Red "Invalid Password!" upon wrong password
                        }
                    }

                    else {
                        if (accountList.contains(user)) {
                            System.out.println(colours.yellowBoldBright + "Please enter your password: " + colours.reset);
                            String pass = console.nextLine();

                            if (pass.equals(acc.get(user))) {
                                System.out.println(colours.greenBoldBright + "\nLogin successful!\n" + colours.reset);
                                menu.onStartUp();
                                menu.guest(user); // Goes to Guest Page
                            }
    
                            else {
                                System.out.println(colours.redBoldBright + "Invalid password!" + colours.reset); //Red "Invalid Password!" upon wrong password
                             }
                        }

                        else {
                            System.out.println(colours.redBoldBright + "Username doesn't exist!" + colours.reset); //Red "Username doesn't exist!" upon user doing something out of expectations.
                        }

                    }
                }

                else if (choice.equals("2")) {
                    System.out.println(colours.greenBoldBright + "Quitting program..." + colours.reset); //Quits program
                    loop = false;
                }
                else {
                    System.out.println(colours.redBoldBright + "Please give a valid input!" + colours.reset);
                }
            }
            console.close();
        }
    }