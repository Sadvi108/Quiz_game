public class lines {
    public static void line(){
        System.out.println("===================");
    }
    public static void longLine() {
        System.out.println("=======================================");
    }
    public static void startUpLine() {
        System.out.println(colours.yellowBoldBright + "===================");
    }
    public static void emptyline(){
        System.out.println("");
    }
}
