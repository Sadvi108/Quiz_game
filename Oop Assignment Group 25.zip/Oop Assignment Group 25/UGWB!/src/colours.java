public class colours {
    public static final String reset = "\033[0m";  // Text reset

    // Regular Colors
    public static final String black = "\033[0;30m";   // black
    public static final String red = "\033[0;31m";     // red
    public static final String green = "\033[0;32m";   // green
    public static final String yellow = "\033[0;33m";  // yellow
    public static final String blue = "\033[0;34m";    // blue
    public static final String purple = "\033[0;35m";  // purple
    public static final String cyan = "\033[0;36m";    // cyan
    public static final String white = "\033[0;37m";   // white

    // Bold
    public static final String blackBold = "\033[1;30m";  // black
    public static final String redBold = "\033[1;31m";    // red
    public static final String greenBold = "\033[1;32m";  // green
    public static final String yellowBold = "\033[1;33m"; // yellow
    public static final String blueBold = "\033[1;34m";   // blue
    public static final String purpleBold = "\033[1;35m"; // purple
    public static final String cyanBold = "\033[1;36m";   // cyan
    public static final String whiteBold = "\033[1;37m";  // white

    // Underline
    public static final String blackUnderlined = "\033[4;30m";  // black
    public static final String redUnderlined = "\033[4;31m";    // red
    public static final String greenUnderlined = "\033[4;32m";  // green
    public static final String yellowUnderlined = "\033[4;33m"; // yellow
    public static final String blueUnderlined = "\033[4;34m";   // blue
    public static final String purpleUnderlined = "\033[4;35m"; // purple
    public static final String cyanUnderlined = "\033[4;36m";   // cyan
    public static final String whiteUnderlined = "\033[4;37m";  // white

    // Background
    public static final String blackBackground = "\033[40m";  // black
    public static final String redBackground = "\033[41m";    // red
    public static final String greenBackground = "\033[42m";  // green
    public static final String yellowBackground = "\033[43m"; // yellow
    public static final String blueBackground = "\033[44m";   // blue
    public static final String purpleBackground = "\033[45m"; // purple
    public static final String cyanBackground = "\033[46m";   // cyan
    public static final String whiteBackground = "\033[47m";  // white

    // High Intensity
    public static final String blackBright = "\033[0;90m";  // black
    public static final String redBright = "\033[0;91m";    // red
    public static final String greenBright = "\033[0;92m";  // green
    public static final String yellowBright = "\033[0;93m"; // yellow
    public static final String blueBright = "\033[0;94m";   // blue
    public static final String purpleBright = "\033[0;95m"; // purple
    public static final String cyanBright = "\033[0;96m";   // cyan
    public static final String whiteBright = "\033[0;97m";  // white

    // Bold High Intensity
    public static final String blackBoldBright = "\033[1;90m"; // black
    public static final String redBoldBright = "\033[1;91m";   // red
    public static final String greenBoldBright = "\033[1;92m"; // green
    public static final String yellowBoldBright = "\033[1;93m";// yellow
    public static final String blueBoldBright = "\033[1;94m";  // blue
    public static final String purpleBoldBright = "\033[1;95m";// purple
    public static final String cyanBoldBright = "\033[1;96m";  // cyan
    public static final String whiteBoldBright = "\033[1;97m"; // white

    // High Intensity backgrounds
    public static final String blackBackgroundBright = "\033[0;100m";// black
    public static final String redBackgroundBright = "\033[0;101m";// red
    public static final String greenBackgroundBright = "\033[0;102m";// green
    public static final String yellowBackgroundBright = "\033[0;103m";// yellow
    public static final String blueBackgroundBright = "\033[0;104m";// blue
    public static final String purpleBackgroundBright = "\033[0;105m"; // purple
    public static final String cyanBackgroundBright = "\033[0;106m";  // cyan
    public static final String whiteBackgroundBright = "\033[0;107m";   // white
}